CREATE VIEW tlr_todaysTransactedAmount_view AS
  SELECT sum(`theteller`.`tlr_transactions`.`transactionAmount`) AS `transactedAmount`
  FROM `theteller`.`tlr_transactions`
  WHERE ((`theteller`.`tlr_transactions`.`transactionDate` = curdate()) AND
         (`theteller`.`tlr_transactions`.`transactionStatus` = 1));
