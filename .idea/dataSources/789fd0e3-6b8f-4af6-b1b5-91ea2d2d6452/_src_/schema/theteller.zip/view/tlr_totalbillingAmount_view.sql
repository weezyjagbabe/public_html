CREATE VIEW tlr_totalbillingAmount_view AS
  SELECT sum(`theteller`.`tlr_transactions`.`billingAmount`) AS `billingAmount`
  FROM `theteller`.`tlr_transactions`
  WHERE (`theteller`.`tlr_transactions`.`transactionStatus` = 1);
