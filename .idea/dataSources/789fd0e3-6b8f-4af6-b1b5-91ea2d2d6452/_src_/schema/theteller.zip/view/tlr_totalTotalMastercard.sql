CREATE VIEW tlr_totalTotalMastercard AS
  SELECT sum(`theteller`.`tlr_transactions`.`transactionAmount`) AS `transactionAmount`
  FROM `theteller`.`tlr_transactions`
  WHERE ((`theteller`.`tlr_transactions`.`transactionStatus` = 1) AND
         (`theteller`.`tlr_transactions`.`paymentSourceKey` = 'cuI6w81aBKse1JK'));
