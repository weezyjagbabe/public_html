CREATE VIEW tlr_totalTotalTigo AS
  SELECT sum(`theteller`.`tlr_transactions`.`transactionAmount`) AS `transactionAmount`
  FROM `theteller`.`tlr_transactions`
  WHERE ((`theteller`.`tlr_transactions`.`transactionStatus` = 1) AND
         (`theteller`.`tlr_transactions`.`paymentSourceKey` = 'eVbK8jYX244dUsY'));
