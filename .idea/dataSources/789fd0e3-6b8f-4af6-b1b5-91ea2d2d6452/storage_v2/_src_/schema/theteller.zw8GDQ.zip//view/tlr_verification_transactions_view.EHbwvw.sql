CREATE VIEW tlr_verification_transactions_view AS
  SELECT
    `theteller`.`tlr_verification_transactions`.`transactionID`        AS `transactionID`,
    `theteller`.`tlr_verification_transactions`.`transactionKey`       AS `transactionKey`,
    `theteller`.`tlr_verification_transactions`.`providerKey`          AS `providerKey`,
    `theteller`.`tlr_verification_transactions`.`transactionAmount`    AS `transactionAmount`,
    `theteller`.`tlr_verification_transactions`.`trasactionCharge`     AS `trasactionCharge`,
    `theteller`.`tlr_verification_transactions`.`billingAmount`        AS `billingAmount`,
    `theteller`.`tlr_verification_transactions`.`transactionRRN`       AS `transactionRRN`,
    `theteller`.`tlr_verification_transactions`.`transactionSRN`       AS `transactionSRN`,
    `theteller`.`tlr_verification_transactions`.`transactionDesc`      AS `transactionDesc`,
    `theteller`.`tlr_verification_transactions`.`transactionDate`      AS `transactionDate`,
    `theteller`.`tlr_verification_transactions`.`transactionTime`      AS `transactionTime`,
    `theteller`.`tlr_verification_transactions`.`transactionStatus`    AS `transactionStatus`,
    `theteller`.`tlr_verification_transactions`.`transactionExtraData` AS `transactionExtraData`,
    `theteller`.`tlr_users`.`userKey`                                  AS `userKey`,
    `theteller`.`tlr_users`.`userEmail`                                AS `userEmail`,
    `theteller`.`tlr_users`.`userTitle`                                AS `userTitle`,
    `theteller`.`tlr_users`.`userFirstName`                            AS `userFirstName`,
    `theteller`.`tlr_users`.`userLastName`                             AS `userLastName`,
    `theteller`.`tlr_users`.`userPhone`                                AS `userPhone`,
    `theteller`.`tlr_users`.`userResAddress`                           AS `userResAddress`,
    `theteller`.`tlr_users`.`dateCreated`                              AS `dateCreated`,
    `theteller`.`tlr_services`.`serviceName`                           AS `serviceName`,
    `theteller`.`tlr_services`.`serviceKey`                            AS `serviceKey`,
    `theteller`.`tlr_services_providers`.`companyName`                 AS `companyName`,
    `theteller`.`tlr_services_providers`.`companyEmail`                AS `companyEmail`,
    `theteller`.`tlr_services_providers`.`companyPhone`                AS `companyPhone`,
    `theteller`.`tlr_services_providers`.`companyAddress`              AS `companyAddress`,
    `theteller`.`tlr_payment_sources`.`paymentSourceName`              AS `paymentSourceName`,
    `theteller`.`tlr_categories`.`categoryKey`                         AS `categoryKey`,
    `theteller`.`tlr_categories`.`categoryName`                        AS `categoryName`
  FROM (((((`theteller`.`tlr_verification_transactions`
    JOIN `theteller`.`tlr_users`
      ON ((`theteller`.`tlr_verification_transactions`.`userKey` = `theteller`.`tlr_users`.`userKey`))) JOIN
    `theteller`.`tlr_services`
      ON ((`theteller`.`tlr_services`.`serviceKey` = `theteller`.`tlr_verification_transactions`.`serviceKey`))) JOIN
    `theteller`.`tlr_services_providers` ON ((`theteller`.`tlr_services_providers`.`providerKey` =
                                              `theteller`.`tlr_verification_transactions`.`providerKey`))) JOIN
    `theteller`.`tlr_payment_sources` ON ((`theteller`.`tlr_payment_sources`.`paymentSourceKey` =
                                           `theteller`.`tlr_verification_transactions`.`paymentSourceKey`))) JOIN
    `theteller`.`tlr_categories`
      ON ((`theteller`.`tlr_services`.`categoryKey` = `theteller`.`tlr_categories`.`categoryKey`)));

