CREATE VIEW tlr_todaysCommissionAmount_view AS
  SELECT sum(`theteller`.`tlr_transactions`.`trasactionCharge`) AS `trasactionCharge`
  FROM `theteller`.`tlr_transactions`
  WHERE ((`theteller`.`tlr_transactions`.`transactionDate` = curdate()) AND
         (`theteller`.`tlr_transactions`.`transactionStatus` = 1));

